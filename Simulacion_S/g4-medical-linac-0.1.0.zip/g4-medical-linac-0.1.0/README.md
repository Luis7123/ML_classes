# g4-medical-linac
A geant4 model of a medical linac

Test commit